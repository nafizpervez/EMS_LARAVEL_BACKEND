<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Hash;
use App\Models\Role;

class UserFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            // 'name' => $this->faker->name(),
            // 'email' => $this->faker->unique()->safeEmail(),
            // 'role_id' => $this->faker->randomElement(Role::all()),
            // 'phone' => $this->faker->unique()->PhoneNumber(),
            // 'address' => $this->faker->address(),
            // 'date_of_birth' => $this->faker->dateTimeBetween('-40 years', '-25 years'),
            // 'joining_date' => $this->faker->dateTimeBetween('-10 years', '-2 years'),
            // 'avater' => $this->faker->image('public/storage/images',256,256, "cats", false),
            // 'email_verified_at' => now(),
            // 'password' => Hash::make('741852963'), // password
            // 'remember_token' => Str::random(10),
        ];
    }

    /**
     * Indicate that the model's email address should be unverified.
     *
     * @return \Illuminate\Database\Eloquent\Factories\Factory
     */
    public function unverified()
    {
        return $this->state(function (array $attributes) {
            return [
                'email_verified_at' => null,
            ];
        });
    }
}
