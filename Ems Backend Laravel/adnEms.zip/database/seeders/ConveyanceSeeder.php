<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

use App\Models\Conveyance;

class ConveyanceSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // Conveyance::create([
        //     'employee_id' => '2010006',
        //     'submission_date' => '2020-09-15',
        //     'overtime' => 0,
        //     'holiday' => 0,
        //     'conveyance_bill' => 1120,
        //     'mobile_bill' => 0,
        //     'night_or_ifter_allowance' => 0,
        //     'total_payable' => 1120,
        //     'remarks' => null,
        // ]);
        // Conveyance::create([
        //     'employee_id' => '2010008',
        //     'submission_date' => '2020-09-15',
        //     'overtime' => 0,
        //     'holiday' => 0,
        //     'conveyance_bill' => 0,
        //     'mobile_bill' => 0,
        //     'night_or_ifter_allowance' => 0,
        //     'total_payable' => 0,
        //     'remarks' => null,
        // ]);
        // Conveyance::create([
        //     'employee_id' => '2010031',
        //     'submission_date' => '2020-09-15',
        //     'overtime' => 2000,
        //     'holiday' => 1200,
        //     'conveyance_bill' => 1710,
        //     'mobile_bill' => 0,
        //     'night_or_ifter_allowance' => 0,
        //     'total_payable' => 4910,
        //     'remarks' => null,
        // ]);
        // Conveyance::create([
        //     'employee_id' => '2010041',
        //     'submission_date' => '2020-09-15',
        //     'overtime' => 2000,
        //     'holiday' => 1200,
        //     'conveyance_bill' => 2500,
        //     'mobile_bill' => 0,
        //     'night_or_ifter_allowance' => 0,
        //     'total_payable' => 5700,
        //     'remarks' => null,
        // ]);
        // Conveyance::create([
        //     'employee_id' => '2010049',
        //     'submission_date' => '2020-09-15',
        //     'overtime' => 2000,
        //     'holiday' => 1400,
        //     'conveyance_bill' => 1650,
        //     'mobile_bill' => 0,
        //     'night_or_ifter_allowance' => 0,
        //     'total_payable' => 5050,
        //     'remarks' => null,
        // ]);
        // Conveyance::create([
        //     'employee_id' => '2010050',
        //     'submission_date' => '2020-09-15',
        //     'overtime' => 0,
        //     'holiday' => 0,
        //     'conveyance_bill' => 0,
        //     'mobile_bill' => 0,
        //     'night_or_ifter_allowance' => 0,
        //     'total_payable' => 0,
        //     'remarks' => null,
        // ]);
        // Conveyance::create([
        //     'employee_id' => '2010132',
        //     'submission_date' => '2020-09-15',
        //     'overtime' => 1500,
        //     'holiday' => 1400,
        //     'conveyance_bill' => 2400,
        //     'mobile_bill' => 0,
        //     'night_or_ifter_allowance' => 0,
        //     'total_payable' => 5300,
        //     'remarks' => null,
        // ]);
        // Conveyance::create([
        //     'employee_id' => '2010139',
        //     'submission_date' => '2020-09-15',
        //     'overtime' => 1000,
        //     'holiday' => 400,
        //     'conveyance_bill' => 1815,
        //     'mobile_bill' => 0,
        //     'night_or_ifter_allowance' => 0,
        //     'total_payable' => 3215,
        //     'remarks' => null,
        // ]);
        // Conveyance::create([
        //     'employee_id' => '2010130',
        //     'submission_date' => '2020-09-15',
        //     'overtime' => 270,
        //     'holiday' => 1000,
        //     'conveyance_bill' => 1425,
        //     'mobile_bill' => 0,
        //     'night_or_ifter_allowance' => 0,
        //     'total_payable' => 2695,
        //     'remarks' => null,
        // ]);
        // Conveyance::create([
        //     'employee_id' => '2010090',
        //     'submission_date' => '2020-09-15',
        //     'overtime' => 0,
        //     'holiday' => 400,
        //     'conveyance_bill' => 2500,
        //     'mobile_bill' => 0,
        //     'night_or_ifter_allowance' => 0,
        //     'total_payable' => 2900,
        //     'remarks' => null,
        // ]);
        // Conveyance::create([
        //     'employee_id' => '2010134',
        //     'submission_date' => '2020-09-15',
        //     'overtime' => 540,
        //     'holiday' => 400,
        //     'conveyance_bill' => 3500,
        //     'mobile_bill' => 0,
        //     'night_or_ifter_allowance' => 0,
        //     'total_payable' => 4440,
        //     'remarks' => null,
        // ]);
        // Conveyance::create([
        //     'employee_id' => '2010163',
        //     'submission_date' => '2020-09-15',
        //     'overtime' => 0,
        //     'holiday' => 800,
        //     'conveyance_bill' => 2500,
        //     'mobile_bill' => 0,
        //     'night_or_ifter_allowance' => 0,
        //     'total_payable' => 3300,
        //     'remarks' => null,
        // ]);
        // Conveyance::create([
        //     'employee_id' => '2010128',
        //     'submission_date' => '2020-09-15',
        //     'overtime' => 1000,
        //     'holiday' => 1200,
        //     'conveyance_bill' => 2500,
        //     'mobile_bill' => 0,
        //     'night_or_ifter_allowance' => 0,
        //     'total_payable' => 4700,
        //     'remarks' => null,
        // ]);
        // Conveyance::create([
        //     'employee_id' => '2010137',
        //     'submission_date' => '2020-09-15',
        //     'overtime' => 2000,
        //     'holiday' => 400,
        //     'conveyance_bill' => 1420,
        //     'mobile_bill' => 0,
        //     'night_or_ifter_allowance' => 0,
        //     'total_payable' => 3820,
        //     'remarks' => null,
        // ]);
        // Conveyance::create([
        //     'employee_id' => '2010144',
        //     'submission_date' => '2020-09-15',
        //     'overtime' => 2000,
        //     'holiday' => 1000,
        //     'conveyance_bill' => 2500,
        //     'mobile_bill' => 0,
        //     'night_or_ifter_allowance' => 0,
        //     'total_payable' => 5500,
        //     'remarks' => null,
        // ]);
        // Conveyance::create([
        //     'employee_id' => '2010141',
        //     'submission_date' => '2020-09-15',
        //     'overtime' => 1200,
        //     'holiday' => 1200,
        //     'conveyance_bill' => 2500,
        //     'mobile_bill' => 0,
        //     'night_or_ifter_allowance' => 0,
        //     'total_payable' => 4900,
        //     'remarks' => null,
        // ]);
        // Conveyance::create([
        //     'employee_id' => '2010156',
        //     'submission_date' => '2020-09-15',
        //     'overtime' => 2000,
        //     'holiday' => 1400,
        //     'conveyance_bill' => 2635,
        //     'mobile_bill' => 0,
        //     'night_or_ifter_allowance' => 0,
        //     'total_payable' => 6035,
        //     'remarks' => null,
        // ]);
        // Conveyance::create([
        //     'employee_id' => '2010146',
        //     'submission_date' => '2020-09-15',
        //     'overtime' => 2500,
        //     'holiday' => 1000,
        //     'conveyance_bill' => 3500,
        //     'mobile_bill' => 0,
        //     'night_or_ifter_allowance' => 0,
        //     'total_payable' => 7000,
        //     'remarks' => null,
        // ]);
        // Conveyance::create([
        //     'employee_id' => '2010159',
        //     'submission_date' => '2020-09-15',
        //     'overtime' => 0,
        //     'holiday' => 0,
        //     'conveyance_bill' => 0,
        //     'mobile_bill' => 0,
        //     'night_or_ifter_allowance' => 0,
        //     'total_payable' => 0,
        //     'remarks' => null,
        // ]);
        // Conveyance::create([
        //     'employee_id' => '2010173',
        //     'submission_date' => '2020-09-15',
        //     'overtime' => 0,
        //     'holiday' => 0,
        //     'conveyance_bill' => 0,
        //     'mobile_bill' => 0,
        //     'night_or_ifter_allowance' => 0,
        //     'total_payable' => 0,
        //     'remarks' => null,
        // ]);
        // Conveyance::create([
        //     'employee_id' => '2010153',
        //     'submission_date' => '2020-09-15',
        //     'overtime' => 0,
        //     'holiday' => 0,
        //     'conveyance_bill' => 300,
        //     'mobile_bill' => 0,
        //     'night_or_ifter_allowance' => 0,
        //     'total_payable' => 300,
        //     'remarks' => null,
        // ]);
        // Conveyance::create([
        //     'employee_id' => '2010150',
        //     'submission_date' => '2020-09-15',
        //     'overtime' => 800,
        //     'holiday' => 800,
        //     'conveyance_bill' => 2000,
        //     'mobile_bill' => 0,
        //     'night_or_ifter_allowance' => 0,
        //     'total_payable' => 3600,
        //     'remarks' => null,
        // ]);
        // Conveyance::create([
        //     'employee_id' => '2010161',
        //     'submission_date' => '2020-09-15',
        //     'overtime' => 2000,
        //     'holiday' => 400,
        //     'conveyance_bill' => 2000,
        //     'mobile_bill' => 0,
        //     'night_or_ifter_allowance' => 0,
        //     'total_payable' => 4400,
        //     'remarks' => null,
        // ]);
        // Conveyance::create([
        //     'employee_id' => '2010166',
        //     'submission_date' => '2020-09-15',
        //     'overtime' => 800,
        //     'holiday' => 1000,
        //     'conveyance_bill' => 4000,
        //     'mobile_bill' => 0,
        //     'night_or_ifter_allowance' => 0,
        //     'total_payable' => 5800,
        //     'remarks' => null,
        // ]);
        // Conveyance::create([
        //     'employee_id' => '2010164',
        //     'submission_date' => '2020-09-15',
        //     'overtime' => 800,
        //     'holiday' => 800,
        //     'conveyance_bill' => 3200,
        //     'mobile_bill' => 0,
        //     'night_or_ifter_allowance' => 0,
        //     'total_payable' => 4800,
        //     'remarks' => null,
        // ]);
        // Conveyance::create([
        //     'employee_id' => '2010165',
        //     'submission_date' => '2020-09-15',
        //     'overtime' => 500,
        //     'holiday' => 800,
        //     'conveyance_bill' => 2500,
        //     'mobile_bill' => 0,
        //     'night_or_ifter_allowance' => 0,
        //     'total_payable' => 3800,
        //     'remarks' => null,
        // ]);
        // Conveyance::create([
        //     'employee_id' => '2010162',
        //     'submission_date' => '2020-09-15',
        //     'overtime' => 800,
        //     'holiday' => 800,
        //     'conveyance_bill' => 4000,
        //     'mobile_bill' => 0,
        //     'night_or_ifter_allowance' => 0,
        //     'total_payable' => 5600,
        //     'remarks' => null,
        // ]);
        // Conveyance::create([
        //     'employee_id' => '2010167',
        //     'submission_date' => '2020-09-15',
        //     'overtime' => 2000,
        //     'holiday' => 1200,
        //     'conveyance_bill' => 2800,
        //     'mobile_bill' => 0,
        //     'night_or_ifter_allowance' => 0,
        //     'total_payable' => 6000,
        //     'remarks' => null,
        // ]);
        // Conveyance::create([
        //     'employee_id' => '2010168',
        //     'submission_date' => '2020-09-15',
        //     'overtime' => 800,
        //     'holiday' => 1000,
        //     'conveyance_bill' => 4200,
        //     'mobile_bill' => 0,
        //     'night_or_ifter_allowance' => 0,
        //     'total_payable' => 6000,
        //     'remarks' => null,
        // ]);
        // Conveyance::create([
        //     'employee_id' => '2010170',
        //     'submission_date' => '2020-09-15',
        //     'overtime' => 1000,
        //     'holiday' => 1400,
        //     'conveyance_bill' => 2355,
        //     'mobile_bill' => 0,
        //     'night_or_ifter_allowance' => 0,
        //     'total_payable' => 4755,
        //     'remarks' => null,
        // ]);
        // Conveyance::create([
        //     'employee_id' => '2020001',
        //     'submission_date' => '2020-09-15',
        //     'overtime' => 2500,
        //     'holiday' => 1320,
        //     'conveyance_bill' => 1475,
        //     'mobile_bill' => 300,
        //     'night_or_ifter_allowance' => 0,
        //     'total_payable' => 5595,
        //     'remarks' => null,
        // ]);
        // Conveyance::create([
        //     'employee_id' => '2020003',
        //     'submission_date' => '2020-09-15',
        //     'overtime' => 3500,
        //     'holiday' => 1320,
        //     'conveyance_bill' => 1000,
        //     'mobile_bill' => 300,
        //     'night_or_ifter_allowance' => 0,
        //     'total_payable' => 6120,
        //     'remarks' => null,
        // ]);
        // Conveyance::create([
        //     'employee_id' => '2020004',
        //     'submission_date' => '2020-09-15',
        //     'overtime' => 3500,
        //     'holiday' => 880,
        //     'conveyance_bill' => 750,
        //     'mobile_bill' => 300,
        //     'night_or_ifter_allowance' => 0,
        //     'total_payable' => 5430,
        //     'remarks' => null,
        // ]);
        // Conveyance::create([
        //     'employee_id' => '2020013',
        //     'submission_date' => '2020-09-15',
        //     'overtime' => 3000,
        //     'holiday' => 440,
        //     'conveyance_bill' => 615,
        //     'mobile_bill' => 300,
        //     'night_or_ifter_allowance' => 0,
        //     'total_payable' => 4355,
        //     'remarks' => null,
        // ]);
        // Conveyance::create([
        //     'employee_id' => '2020018',
        //     'submission_date' => '2020-09-15',
        //     'overtime' => 2000,
        //     'holiday' => 660,
        //     'conveyance_bill' => 4000,
        //     'mobile_bill' => 300,
        //     'night_or_ifter_allowance' => 0,
        //     'total_payable' => 6960,
        //     'remarks' => null,
        // ]);
        // Conveyance::create([
        //     'employee_id' => '2020032',
        //     'submission_date' => '2020-09-15',
        //     'overtime' => 3100,
        //     'holiday' => 880,
        //     'conveyance_bill' => 720,
        //     'mobile_bill' => 300,
        //     'night_or_ifter_allowance' => 0,
        //     'total_payable' => 5000,
        //     'remarks' => null,
        // ]);
        
    }
}
